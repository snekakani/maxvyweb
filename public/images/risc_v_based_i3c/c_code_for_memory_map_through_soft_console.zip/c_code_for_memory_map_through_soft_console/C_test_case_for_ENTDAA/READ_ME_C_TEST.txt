/****************Steps to run C test cases*****************************/

**Note: before doing all these following steps make sure to dump code inside microsemi board and connect USB with board to your system.


1)download soft console 6.0 version

2)Check the default run configurations->debugger, if it belongs to RISC-V configuration in config options then leave as it is otherwise change taht to RISC-V configuration

3)incluse existing project miv_rv32im_systick_blinky project from soft console examples, in that modify the main.c with model test we have given here

4)make sure to change the SYS_CLK_FREQ to  66600000UL inside the hw_platform.h and sample_hw_platform.h

5)Add the symbol MSCC_STDIO_THRU_CORE_UART_APB inside the properties->C,C++ Build->settings->toolsettings->GNU_RISC-V cross C Compiler->preporcessor to see outputs of Printf statements in terminal

6)After changing all settings build the project check for errors in console

7)To set the terminal to see output right click on terminal then connect with COM port in which FLASH pro5 got connected

8)Run the code and see the output value of read data from Terminal

 
