Model test bench will work for Private write, Private read and SETMWL broadcast CCC functions



