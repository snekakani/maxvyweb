`timescale 1ns/1ns
`define tcq 10ns
`define ideal_time_add 32'h78
`define ideal_time_val 'd27
`define clk_port_val 'h1001
`define clk_port_add 32'h44
`define data_transfer_add0 32'h3c0000
`define data_transfer_add1 32'h3c0004
`define wr_data_port_add 32'h84
`define rd_data_port_add 32'h88
`define dat_address0 32'h30_00
`define broadcast_reg_add 32'h18

module ahb_i3c_tb();

reg hwrite_tb;
reg hreset_tb;
reg hclk_tb;
reg [31:0] haddr_tb;
reg [31:0] hwdata_tb;
reg [2:0] hburst_tb;
reg [2:0] hsize_tb;
reg [1:0] htrans_tb;
reg sda_reg_tb;
reg sda_drv_en_tb;

wire hresp_tb;
wire hready_tb;
wire cpu_interrupt_tb;
wire [31:0] hrdata_tb;
wire scl_out_tb;
wire sda_out_en_tb;
wire scl_out_en_tb;
wire sda_out_tb;
wire  scl_pad;
wire scl;
wire  sda_pad;
wire sda;

assign scl =scl_pad;
assign sda= sda_pad;

pullup p1 (sda_pad);

dut_top dut (.hreset(hreset_tb),
			   .hclk(hclk_tb),
			   .haddr(haddr_tb),
			   .hburst(hburst_tb),
			   .hsize(hsize_tb),
			   .htrans(htrans_tb),
			   .hwdata(hwdata_tb),
			   .hwrite(hwrite_tb),
			   .hsel(1'b1),
			   .hrdata(hrdata_tb),
			   .hready(hready_tb),
			   .hresp(hresp_tb),
			   .cpu_interrupt(cpu_interrupt_tb),
			   .scl_in(scl),
			   .scl_out(scl_out_tb),
			   .sda_in(sda),
			   .sda_out(sda_out_tb),
			    .src_clk(hclk_tb),
			   .scl_out_en(scl_out_en_tb),
			   .sda_out_en(sda_out_en_tb),			   
			   .reset(~hreset_tb));						   
			   
//SCL pad instantiation

scl_drive_pad u0_scl_pad(
						.scl_data_in(scl_out_tb),
						.scl_data_en(scl_out_en_tb),
						.scl(scl_pad),
						.scl_out()
						);
		

						
scl_drive_pad u0_sda_pad(
						.scl_data_in(sda_out_tb),
						.scl_data_en(sda_out_en_tb),
						.scl(sda_pad),
						.scl_out()
						);
						
scl_drive_pad u1_sda_pad(
						.scl_data_in(sda_reg_tb),
						.scl_data_en(sda_drv_en_tb),
						.scl(sda_pad),
						.scl_out(sda)
						);

						
task register_write(input [31:0] h_addr,input [31:0] h_wdata);
@(negedge hclk_tb);
haddr_tb=h_addr;
hwrite_tb=1'b1;
hsize_tb= 3'b000;
hburst_tb= 3'b000; 
htrans_tb=2'b10; 
@(posedge hclk_tb);
hwdata_tb=h_wdata;
endtask


task ahbl_idle();
 @(negedge hclk_tb);
	htrans_tb = 2'b00;
endtask


task write_data();
register_write(`ideal_time_add,`ideal_time_val);
register_write(`clk_port_add,`clk_port_val);
register_write(`dat_address0,{8'h0,8'h5b,16'h000});
register_write(`data_transfer_add0,32'h80000000);
register_write(`data_transfer_add1,32'h00010000);
register_write(`wr_data_port_add,'hbb);
ahbl_idle(); 
 repeat(8) @(posedge scl);
 @(negedge scl)
 sda_drv_en_tb=1;sda_reg_tb=0;
@(posedge scl);
@(negedge scl);
sda_drv_en_tb=0;
endtask

task read_data();
register_write(`ideal_time_add,`ideal_time_val);
register_write(`clk_port_add,`clk_port_val);
register_write(`dat_address0,{8'h0,8'h5b,16'h000});
register_write(`data_transfer_add0,32'ha0000000);
register_write(`data_transfer_add1,32'h00010000);
 ahbl_idle(); 
 repeat(8) @(posedge scl);
 @(negedge scl)
sda_drv_en_tb = 1;sda_reg_tb=0;
repeat(5) @(negedge scl)
sda_reg_tb=1;
 repeat(4) @(negedge scl)
 sda_reg_tb=0;  
@(posedge scl);
@(negedge scl);
sda_drv_en_tb=0; 
endtask

task B_setmwl();
register_write(`ideal_time_add,`ideal_time_val);
register_write(`clk_port_add,`clk_port_val);
register_write(`broadcast_reg_add,{7'h7e,1'b0});
register_write(`data_transfer_add0,32'h00001207);
register_write(`data_transfer_add1,32'h00000000);
register_write(`data_transfer_add0,{6'h20,3'h2,7'h0,1'h1,8'h09,7'h01});
register_write(`data_transfer_add1,32'h00000abef);
ahbl_idle(); 
 repeat(8) @(posedge scl);
 @(negedge scl)
 sda_drv_en_tb=1;sda_reg_tb=0;
@(posedge scl);
@(negedge scl);
sda_drv_en_tb=0;
endtask

initial
begin
forever
begin
@(posedge scl)
 $display("The I3C Master slave information on the sda line at [%0t] is %b",$time, sda);
 end
 end

 always #10 hclk_tb=~hclk_tb;	

initial
begin
 sda_drv_en_tb=0;
 sda_reg_tb=0; 
 hclk_tb=0;
haddr_tb=32'b0;
hwdata_tb=32'b0;
 hwrite_tb=1'b0;
hsize_tb= 3'b000;
hburst_tb= 3'b000; 
htrans_tb=2'b00; 
hreset_tb=0;
	 @(posedge hclk_tb);
	  @(posedge hclk_tb);
 hreset_tb=1;	 
  #1000
     write_data ();
#1000
    read_data();
#1000
     B_setmwl();
 #15000 $finish;
end

endmodule


module scl_drive_pad(
input scl_data_in,
input scl_data_en,
inout  scl,
output scl_out);

bufif1 b2(scl,scl_data_in,scl_data_en);
bufif0 b3(scl_out,scl,scl_data_en);
 
endmodule
